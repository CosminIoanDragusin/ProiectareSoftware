package ro.ulbs.ip.an3.frontend;

import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.ws.rs.ClientErrorException;

@SessionScoped
@Named("empMBean")
public class EmployeeMBean implements Serializable {

    private static final long serialVersionUID = 10112;

    @EJB
    private EmployeeRest restClient;

    private int filterId;
    private String filterText;
    private EmployeeDto selectedEmployee;
    private boolean isCreate;
    private boolean isEdit;
    private boolean isDelete;

    public String getStartingPage() {
        return "employees";
    }

    public List<EmployeeDto> getEmployees() {
        if (filterId > 0) {
            return restClient.filterById(filterId);
        } else if (filterText != null && filterText.length() > 0) {
            return restClient.filterBy(filterText);
        } else {
            return restClient.listAll();
        }
    }

    public String getFilterText() {
        return filterText;
    }

    public void setFilterText(String filterText) {
        this.filterText = filterText;
        this.filterId = 0;
    }

    public int getFilterId() {
        return filterId;
    }

    public void setFilterId(int filterId) {
        this.filterId = filterId;
        if (filterId > 0) {
            this.filterText = null;
        }
    }

    public void filter() {
    }

    public void filterById() {
        try {
            filterId = Integer.parseInt(filterText);
        } catch (NumberFormatException nfe) {
        }
        filterText = null;
    }

    public void setSelected(EmployeeDto e) {
        this.selectedEmployee = e;
    }

    public EmployeeDto getSelected() {
        return selectedEmployee;
    }

    public String startCreate() {
        isCreate = true;
        selectedEmployee = new EmployeeDto();
        selectedEmployee.setDepartment(new DepartmentDto());
        return "employee_create_or_edit";
    }

    public String endCreate() {
        try {
            Integer createdId = restClient.create(selectedEmployee);
            String msg = "Employee created id " + createdId;
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", msg);
            FacesContext.getCurrentInstance().addMessage(null, facesMessage);
        } catch (ClientErrorException ex) {
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", ex.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, facesMessage);
        }
        isCreate = false;
        return getStartingPage();
    }

    public String startEdit() {
        if (selectedEmployee.getDepartment() == null) {
            selectedEmployee.setDepartment(new DepartmentDto());
        }
        isEdit = true;
        isCreate = false;
        isDelete = false;
        return "employee_create_or_edit";
    }

    public String endEdit() {
        try {
            restClient.edit(selectedEmployee);
        } catch (ClientErrorException ex) {
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error occured", ex.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, facesMessage);
        }
        isEdit = false;
        return getStartingPage();
    }

    public String startDelete() {
        isDelete = true;
        return "employee_delete";
    }

    public String endDelete() {
        isDelete = false;
        try {
            restClient.delete(selectedEmployee);
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO, "User was succesfully deleted", "User was succesfully deleted");
            FacesContext.getCurrentInstance().addMessage(null, facesMessage);
        } catch (Exception ex) {
            FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, ex.getMessage(), ex.getMessage());
            FacesContext.getCurrentInstance().addMessage(null, facesMessage);
        }
        return getStartingPage();
    }

    public boolean isIsCreate() {
        return isCreate;
    }

    public void setIsCreate(boolean isCreate) {
        this.isCreate = isCreate;
    }

    public boolean isIsDelete() {
        return isDelete;
    }

    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }

    public boolean isIsEdit() {
        return isEdit;
    }

    public void setIsEdit(boolean isEdit) {
        this.isEdit = isEdit;
    }

}
