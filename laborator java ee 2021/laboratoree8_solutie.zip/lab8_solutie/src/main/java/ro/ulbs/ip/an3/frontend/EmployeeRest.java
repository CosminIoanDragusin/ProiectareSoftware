package ro.ulbs.ip.an3.frontend;

import java.util.Arrays;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@LocalBean
public class EmployeeRest {

    private static final String BASE_URI = "http://localhost:8080/restservices/employees";

    private final WebTarget webTarget;
    private final Client client;

    public EmployeeRest() {
        client = javax.ws.rs.client.ClientBuilder.newClient(); 
        webTarget = client.target(BASE_URI);
    }

    public List<EmployeeDto> listAll() throws javax.ws.rs.ClientErrorException {
        //apel GET cu precizarea formatului dorit al datelor
        Response resp = webTarget.
                request(MediaType.APPLICATION_JSON).
                get(Response.class);
        
        //transformarea datelor in obiecte java
        List<EmployeeDto> ret = resp.readEntity(new GenericType<List<EmployeeDto>>() {
        });

        return ret;
    }

    public List<EmployeeDto> filterBy(String name) throws ClientErrorException {
        Response resp = webTarget.path("/search")
                .queryParam("filter", name)
                .request(MediaType.APPLICATION_JSON)
                .get(Response.class);
        List<EmployeeDto> list =  resp.readEntity(new GenericType<List<EmployeeDto>>() {
        });
        return list;
    }
    
    public List<EmployeeDto> filterById(Integer id) throws ClientErrorException {
        Response resp = webTarget.path("/"+id)
                .request(MediaType.APPLICATION_JSON)
                .get(Response.class);
        EmployeeDto emp = resp.readEntity(new GenericType<EmployeeDto>() {
        });
        return Arrays.asList(emp);
    }

    public Integer create(EmployeeDto entry) throws ClientErrorException {
        Response resp = webTarget
                .request(MediaType.APPLICATION_JSON)
                .put(javax.ws.rs.client.Entity.entity(entry, MediaType.APPLICATION_JSON), Response.class);
        String s = resp.readEntity(String.class);
        try {
            Integer id = Integer.parseInt(s);
            return id;
        } catch (NumberFormatException nfe) {
            return 0;
        }
    }
    
    public void edit(EmployeeDto entry) throws ClientErrorException {
        Response resp = webTarget
                .request(MediaType.APPLICATION_JSON)
                .post(javax.ws.rs.client.Entity.entity(entry, MediaType.APPLICATION_JSON), Response.class);
    }
    
    public void delete(EmployeeDto entry) throws javax.ws.rs.ClientErrorException{
        webTarget.path("/"+entry.getId())
                .request(MediaType.APPLICATION_JSON)
                .delete(Response.class);
    }

    
}
