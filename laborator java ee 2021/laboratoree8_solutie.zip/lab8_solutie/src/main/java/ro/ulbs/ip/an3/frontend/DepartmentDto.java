package ro.ulbs.ip.an3.frontend;

import java.io.Serializable;

public class DepartmentDto implements Serializable {
    private static final long serialVersionUID = 1111L;
    private Integer id;
    private String name;
    
    public DepartmentDto() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
