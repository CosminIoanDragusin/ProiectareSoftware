package ro.ulbs.ip.an3.frontend;

import java.util.Arrays;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Stateless
@LocalBean
public class DepartmentRest {

    private static final String BASE_URI = "http://localhost:8080/restservices/departments";

    private final WebTarget webTarget;
    private final Client client;

    public DepartmentRest() {
        //instantierea unui client REST
        client = javax.ws.rs.client.ClientBuilder.newClient(); 
        
        //fiecare url va necesita o noua instanta WebTarget
        webTarget = client.target(BASE_URI);
    }

    public List<DepartmentDto> listAll() throws javax.ws.rs.ClientErrorException {
        //apel GET cu precizarea formatului dorit al datelor
        Response resp = webTarget.
                request(MediaType.APPLICATION_JSON).
                get(Response.class);
        
        //transformarea datelor in obiecte java
        List<DepartmentDto> ret = resp.readEntity(new GenericType<List<DepartmentDto>>() {
        });
        return ret;
    }

    public List<DepartmentDto> filterBy(String name) throws ClientErrorException {
        Response resp = webTarget.path("/search")
                .queryParam("filter", name)
                .request(MediaType.APPLICATION_JSON)
                .get(Response.class);
        return resp.readEntity(new GenericType<List<DepartmentDto>>() {
        });
    }
    
    public List<DepartmentDto> filterById(Integer id) throws ClientErrorException {
        Response resp = webTarget.path("/"+id)
                .request(MediaType.APPLICATION_JSON)
                .get(Response.class);
        DepartmentDto d = resp.readEntity(new GenericType<DepartmentDto>() {
        });
        return Arrays.asList(d);
    }

    public Integer create(DepartmentDto entry) throws ClientErrorException {
        Response resp = webTarget.request(MediaType.APPLICATION_JSON).put(javax.ws.rs.client.Entity.entity(entry, MediaType.APPLICATION_JSON), Response.class);
        String s = resp.readEntity(String.class);
        try {
            Integer id = Integer.parseInt(s);
            return id;
        } catch (NumberFormatException nfe) {
            return 0;
        }
    }
    
    public void edit(DepartmentDto entry) throws ClientErrorException {
        Response resp = webTarget
                .request(MediaType.APPLICATION_JSON)
                .post(javax.ws.rs.client.Entity.entity(entry, MediaType.APPLICATION_JSON), Response.class);
    }
    
    public void delete(DepartmentDto entry) throws javax.ws.rs.ClientErrorException{
        webTarget.path("/"+entry.getId())
                .request(MediaType.APPLICATION_JSON)
                .delete(Response.class);
    }
}
