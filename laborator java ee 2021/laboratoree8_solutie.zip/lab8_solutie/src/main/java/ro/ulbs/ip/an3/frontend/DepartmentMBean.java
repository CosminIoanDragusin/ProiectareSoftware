package ro.ulbs.ip.an3.frontend;

import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@SessionScoped
@Named("deptMBean")
public class DepartmentMBean implements Serializable {

    private static final long serialVersionUID = 10112;

    @EJB
    private DepartmentRest restClient;

    private int filterId;
    private String filterText;
    private DepartmentDto selectedDepartment;
    private boolean isCreate;
    private boolean isDelete;
    private Integer createdId;

    public DepartmentMBean() {
    }

    public List<DepartmentDto> getDepartments() {
        if(filterId > 0) {
            return restClient.filterById(filterId);
        } else if (filterText != null && filterText.length() > 0) {
            return restClient.filterBy(filterText);
        } else {
            return restClient.listAll();
        }
    }
    
    public List<DepartmentDto> getAllDepartments() {
        return restClient.listAll();
    }


    public String getFilterText() {
        return filterText;
    }

    public void setFilterText(String filterText) {
        this.filterText = filterText;
        this.filterId = 0;
    }

    public int getFilterId() {
        return filterId;
    }

    public void setFilterId(int filterId) {
        this.filterId = filterId;
        this.filterText = null;
    }

    public void filter() {
    }
    
    public void filterById() {
        try {
            filterId = Integer.parseInt(filterText);
        }catch(NumberFormatException nfe) {
        }
        filterText = null;
    }

    public void setSelected(DepartmentDto dpt) {
        this.selectedDepartment = dpt;
    }

    public DepartmentDto getSelected() {
        return selectedDepartment;
    }

    public String startCreate() {
        isCreate = true;
        createdId = null;
        selectedDepartment = new DepartmentDto();
        return "department_create";
    }

    public String endCreate() {
        createdId = restClient.create(selectedDepartment);
        isCreate = false;
        return "index";
    }

    public String startEdit() {
        return "department_edit";
    }

    public String endEdit() {
        restClient.edit(selectedDepartment);
        return "index";
    }
    
    public Integer getCreatedId() {
        return createdId;
    }

    public void setCreatedId(Integer createdId) {
        this.createdId = createdId;
    }

    public String startDelete() {
        isDelete = true;
        return "department_delete";
    }

    public String endDelete() {
        isDelete = false;
        try {
            restClient.delete(selectedDepartment);
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage("deptFilterForm", new FacesMessage("Error", e.getMessage()));
        }
        return "index";
    }

    public boolean isIsCreate() {
        return isCreate;
    }

    public void setIsCreate(boolean isCreate) {
        this.isCreate = isCreate;
    }

    public boolean isIsDelete() {
        return isDelete;
    }

    public void setIsDelete(boolean isDelete) {
        this.isDelete = isDelete;
    }
}
