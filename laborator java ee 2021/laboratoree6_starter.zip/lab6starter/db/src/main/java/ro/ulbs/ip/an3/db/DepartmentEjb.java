package ro.ulbs.ip.an3.db;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class DepartmentEjb {

    @PersistenceContext(unitName = "thepersistenceunit")  //see main/resources/META-INF/peristence.xml
    protected EntityManager em;

    private EntityManager getEntityManager() {
        return em;
    }

    public List<Department> getList() {
        EntityManager manager = getEntityManager();
        List<Department> depts = new ArrayList<>();
        try {
            depts = manager.createQuery("SELECT d FROM Department d").getResultList();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return depts;
    }

    public List<Department> filter(String filter) {
        EntityManager manager = getEntityManager();
        List<Department> depts = manager
                .createQuery("SELECT d FROM Department d WHERE d.name like :param")
                .setParameter("param", filter)
                .getResultList();
        return depts;

    }

    public Department filterById(Integer id) {
        EntityManager manager = getEntityManager();
        Department dept = (Department) manager
                .createQuery("SELECT d FROM Department d WHERE d.id = :param")
                .setParameter("param", id)
                .getSingleResult();
        return dept;
    }

    public Integer createDepartment(Department dept) {
        EntityManager manager = getEntityManager();
        manager.persist(dept);
        manager.flush();
        return dept.getId();
    }
    
    public Department updateDepartment(Department dept) {
        EntityManager manager = getEntityManager();
        manager.merge(dept);
        return dept;
    }

}
