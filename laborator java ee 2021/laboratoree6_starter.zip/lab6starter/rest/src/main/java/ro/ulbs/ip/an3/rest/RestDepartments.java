package ro.ulbs.ip.an3.rest;

import ro.ulbs.ip.an3.db.DepartmentEjb;
import ro.ulbs.ip.an3.db.Department;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;

import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.core.Response;

import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

/**
 * REST Web Service
 */
/* WHEN ERRORS: https://stackoverflow.com/questions/40540110/javax-naming-namenotfoundexception-cdiextension
http://localhost:4848/
Glassfish admin console: Configuration > server-config > JVM Settings > tab ‘JVM Options’ >
Add a new entry:
    -Dcom.sun.jersey.server.impl.cdi.lookupExtensionInBeanManager=true
Restart your server
*/

@Path("/departments")
@Stateless
public class RestDepartments {
    
    @Context
    private UriInfo context;
    
    @EJB
    private DepartmentEjb departmentsEjb;

    /**
     * Creates a new instance of WebServices
     */
    public RestDepartments() {
        
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getList() {
        List<Department> depts = departmentsEjb.getList();
        return Response.ok(depts).build();
    }

    @GET
    @Path("/search")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response filter(@DefaultValue("") @QueryParam("filter") String filterTxt,
            @Context HttpServletRequest servletRequest) {
        
        List<Department> depts = departmentsEjb.filter(filterTxt);
        return Response.ok(depts).build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response filter(@PathParam("id") Integer id,
            @Context HttpServletRequest servletRequest) {
        
        Department dept = departmentsEjb.filterById(id);
        return Response.ok(dept).build();
    }

    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response newDepartment(Department dept) {
        
        Integer id = departmentsEjb.createDepartment(dept);
        return Response.ok(id).build();
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateDepartment(Department dept) {
        
        Department result = departmentsEjb.updateDepartment(dept);
        return Response.ok(result).build();
    }
   
}
