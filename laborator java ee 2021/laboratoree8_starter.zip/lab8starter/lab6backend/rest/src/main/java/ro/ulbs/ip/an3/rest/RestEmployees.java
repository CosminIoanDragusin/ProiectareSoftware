package ro.ulbs.ip.an3.rest;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import ro.ulbs.ip.an3.db.Employee;
import ro.ulbs.ip.an3.db.EmployeeEjb;

@Path("/employees")
@Stateless
public class RestEmployees {
    
    @EJB
    private EmployeeEjb employeeEjb;

    /**
     * Creates a new instance of WebServices
     */
    public RestEmployees() {
        
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getList() {
        List<Employee> angajati = employeeEjb.getList();
        return Response.ok(angajati).build();
    }

    @GET
    @Path("/search")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response filter(@DefaultValue("") @QueryParam("filter") String filterTxt,
            @Context HttpServletRequest servletRequest) {
        
        List<Employee> angajati = employeeEjb.filter(filterTxt);
        return Response.ok(angajati).build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response filter(@PathParam("id") Integer id,
            @Context HttpServletRequest servletRequest) {
        
        Employee angajat = employeeEjb.findById(id);
        return Response.ok(angajat).build();
    }

    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response newEmployee(Employee angajat) {
        
        Integer id = employeeEjb.createEmployee(angajat);
        return Response.ok(id).build();
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateEmployee(Employee angajat) {
        
        Employee result = employeeEjb.updateEmployee(angajat);
        return Response.ok(result).build();
    }
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public void delete(@PathParam("id") Integer id,
            @Context HttpServletRequest servletRequest) {
        
        employeeEjb.deleteById(id);
    }
   
}
