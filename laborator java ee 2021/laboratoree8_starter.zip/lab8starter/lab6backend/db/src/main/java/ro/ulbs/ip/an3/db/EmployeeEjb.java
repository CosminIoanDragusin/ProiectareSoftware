package ro.ulbs.ip.an3.db;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class EmployeeEjb {
    
    @EJB
    private DepartmentEjb departmentBean;

    @PersistenceContext(unitName = "thepersistenceunit") 
    protected EntityManager em;

    public List<Employee> getList() {
        List<Employee> employees = em.createQuery("SELECT e FROM Employee e").getResultList();
        return employees;
    }

    public List<Employee> filter(String filter) {
        List<Employee> employess = em
                .createQuery("SELECT e FROM Employee e WHERE e.firstname like :param1 or e.lastname like :param2")
                .setParameter("param1", filter)
                .setParameter("param2", filter)
                .getResultList();
        return employess;

    }

    public Employee findById(Integer id) {
        Employee empl = (Employee) em
                .createQuery("SELECT e FROM Employee e WHERE e.id = :param")
                .setParameter("param", id)
                .getSingleResult();
        return empl;
    }

    public Integer createEmployee(Employee e) {
        em.persist(e);
        em.flush();
        return e.getId();
    }
    
    public Employee updateEmployee(Employee e) {
        Department d = departmentBean.findById(e.getDepartment().getId());
        e.setDepartment(d);
        em.merge(e);
        return e;
    }

    public Employee deleteById(Integer id) {
        Employee empl = findById(id);
        if (empl != null) {
            em.remove(empl);
        }
        return empl;
    }
}
