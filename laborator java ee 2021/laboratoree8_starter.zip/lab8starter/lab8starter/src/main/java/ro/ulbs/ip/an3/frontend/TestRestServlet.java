package ro.ulbs.ip.an3.frontend;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "TestRestServlet", urlPatterns = {"/TestRestServlet"})
public class TestRestServlet extends HttpServlet {

    @EJB
    private DepartmentRest restClient;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html><html><body>");
            List<DepartmentDto> departamente = restClient.listAll();
            out.print("Au fost gasite ");
            out.print(departamente.size());
            out.println(" departamente. <br/>");
            out.println("<table border=\"1\" style=\"border-collapse: collapse\">");
            for (DepartmentDto dept: departamente) {
                out.print("<tr><td>");
                out.print(dept.getId());
                out.print("</td><td>");
                out.print(dept.getName());
                out.println("</td></tr>");
            }
            out.println("</table></body></html>");
        }
    }
}
